import { ReactNode } from 'react';
export declare function BrandLockup({ assetBase, inverse, label, className }: {
    assetBase?: string;
    inverse?: boolean;
    label?: string;
    className?: string;
}): import('react').JSX.Element;
export declare function EditorialHero({ eyebrow, title, description, image, actions, caption }: {
    eyebrow?: string;
    title: ReactNode;
    description: string;
    image: ReactNode;
    actions: ReactNode;
    caption?: ReactNode;
}): import('react').JSX.Element;
