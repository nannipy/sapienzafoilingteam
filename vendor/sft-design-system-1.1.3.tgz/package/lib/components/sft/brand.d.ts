import { ComponentProps, ReactNode } from 'react';
import { Button } from '../ui/button';
export { BrandLockup, EditorialHero } from './identity';
export declare function ActionButton({ loading, children, disabled, ...props }: ComponentProps<typeof Button> & {
    loading?: boolean;
}): import('react').JSX.Element;
export declare function PageHeader({ eyebrow, title, description, actions, level }: {
    eyebrow?: string;
    title: string;
    description?: string;
    actions?: ReactNode;
    level?: 1 | 2 | 3;
}): import('react').JSX.Element;
export declare function Hero({ image, alt, title, description, eyebrow, children, level }: {
    image: string;
    alt: string;
    title: string;
    description: string;
    eyebrow?: string;
    children?: ReactNode;
    level?: 1 | 2;
}): import('react').JSX.Element;
export declare const departments: readonly [{
    readonly id: "scafo";
    readonly name: "Scafo e terrazze";
    readonly description: "Progettazione dello scafo e delle strutture.";
    readonly icon: import('react').ForwardRefExoticComponent<Omit<import('lucide-react').LucideProps, "ref"> & import('react').RefAttributes<SVGSVGElement>>;
}, {
    readonly id: "management";
    readonly name: "Management e Comunicazione";
    readonly description: "Relazioni, organizzazione e racconto del progetto.";
    readonly icon: import('react').ForwardRefExoticComponent<Omit<import('lucide-react').LucideProps, "ref"> & import('react').RefAttributes<SVGSVGElement>>;
}, {
    readonly id: "materiali";
    readonly name: "Materiali e Sostenibilità";
    readonly description: "Scelta dei materiali e valutazione del loro impatto.";
    readonly icon: import('react').ForwardRefExoticComponent<Omit<import('lucide-react').LucideProps, "ref"> & import('react').RefAttributes<SVGSVGElement>>;
}, {
    readonly id: "manufacturing";
    readonly name: "Manufacturing e Cantiere";
    readonly description: "Costruzione, lavorazioni e assemblaggio.";
    readonly icon: import('react').ForwardRefExoticComponent<Omit<import('lucide-react').LucideProps, "ref"> & import('react').RefAttributes<SVGSVGElement>>;
}, {
    readonly id: "foil";
    readonly name: "Foil e Controllo di Volo";
    readonly description: "Foil, assetto e regolazione del volo.";
    readonly icon: import('react').ForwardRefExoticComponent<Omit<import('lucide-react').LucideProps, "ref"> & import('react').RefAttributes<SVGSVGElement>>;
}, {
    readonly id: "elettronica";
    readonly name: "Elettronica e Software";
    readonly description: "Elettronica di bordo e strumenti software.";
    readonly icon: import('react').ForwardRefExoticComponent<Omit<import('lucide-react').LucideProps, "ref"> & import('react').RefAttributes<SVGSVGElement>>;
}, {
    readonly id: "shore";
    readonly name: "Shore Team e Logistica";
    readonly description: "Preparazione, logistica e supporto a terra.";
    readonly icon: import('react').ForwardRefExoticComponent<Omit<import('lucide-react').LucideProps, "ref"> & import('react').RefAttributes<SVGSVGElement>>;
}];
export declare function DepartmentCard({ department, href }: {
    department: typeof departments[number];
    href?: string;
}): import('react').JSX.Element;
declare const tones: {
    readonly neutral: "bg-muted text-muted-foreground";
    readonly success: "bg-success-soft text-success";
    readonly warning: "bg-warning-soft text-warning";
    readonly info: "bg-info-soft text-info";
    readonly danger: "bg-destructive/10 text-destructive";
};
export declare function StatusBadge({ tone, children }: {
    tone?: keyof typeof tones;
    children: ReactNode;
}): import('react').JSX.Element;
export declare function Metric({ label, value, unit, description }: {
    label: string;
    value: string | number;
    unit?: string;
    description?: string;
}): import('react').JSX.Element;
export declare function EmptyState({ title, description, action }: {
    title: string;
    description: string;
    action?: ReactNode;
}): import('react').JSX.Element;
export declare function SponsorGrid({ sponsors }: {
    sponsors: readonly {
        name: string;
        image: string;
        href?: string;
    }[];
}): import('react').JSX.Element;
export declare function ContentCard({ kind, title, description, image, alt, href, meta }: {
    kind: 'Evento' | 'Articolo';
    title: string;
    description: string;
    image: string;
    alt: string;
    href: string;
    meta?: string;
}): import('react').JSX.Element;
export declare function ActivityItem({ title, time, description }: {
    title: string;
    time: {
        label: string;
        iso: string;
    };
    description?: string;
}): import('react').JSX.Element;
export declare function SocialTemplate({ kind, title, description, image, assetBase, footer, format }: {
    kind?: 'update' | 'recruiting' | 'technical' | 'event' | 'sponsor';
    title: string;
    description: string;
    image: string;
    assetBase?: string;
    footer?: string;
    format?: 'post' | 'story' | 'slide';
}): import('react').JSX.Element;
