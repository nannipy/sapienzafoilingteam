export declare function ComboBox({ label, value, onChange, options }: {
    label: string;
    value: string;
    onChange: (value: string) => void;
    options: readonly {
        value: string;
        label: string;
    }[];
}): import('react').JSX.Element;
export declare function DatePicker({ label, value, onChange }: {
    label: string;
    value?: Date;
    onChange: (value: Date | undefined) => void;
}): import('react').JSX.Element;
export type ActivityRow = {
    id: string;
    title: string;
    department: string;
    status: 'Da iniziare' | 'In corso' | 'Completato';
};
export declare function DataTable({ rows, pageSize }: {
    rows: readonly ActivityRow[];
    pageSize?: number;
}): import('react').JSX.Element;
export declare function LineChart({ title, points, unit }: {
    title: string;
    points: readonly {
        label: string;
        value: number;
    }[];
    unit: string;
}): import('react').JSX.Element;
