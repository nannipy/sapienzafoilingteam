import { Label as LabelPrimitive } from 'radix-ui';
import * as React from "react";
declare function Label({ className, ...props }: React.ComponentProps<typeof LabelPrimitive.Root>): React.JSX.Element;
export { Label };
