# Sapienza Foiling Team — Design System 1.1.1

Identità, libreria React basata su shadcn, catalogo interattivo e kit per la comunicazione. Il sito esistente è il riferimento per marchio, bordeaux, Kelson e fotografie.

## Consulta

- `dist/index.html`: catalogo compilato, da servire via HTTP.
- `dist/design-system.html`: documento illustrato, con codice completo dei componenti.
- `docs/DESIGN_SYSTEM_COMPLETO.md`: documento e appendice del codice.
- `public/templates`: nove master SVG con testi separati e nove export PNG.
- `public/brand`: loghi, font, fotografie, pattern e token.
- `public/communication/canva-review.html`: collegamenti e anteprime delle nove bozze Canva.

## Avvio

Con Node 22.12+ e npm: `npm ci`, poi `npm run dev`. Il catalogo è disponibile su http://127.0.0.1:5180.

`npm test` esegue le verifiche di comportamento e contrasto. `npm run build` compila catalogo, libreria, dichiarazioni TypeScript e documento. `npm run pack:release` produce il pacchetto installabile nella cartella release.

## Usa nei progetti

Installa il file `release/sft-design-system-1.1.1.tgz` con npm. Importa una volta `@sft/design-system/styles.css`, poi i componenti da `@sft/design-system`. Servi gli asset necessari da `public/brand` nel progetto destinatario. Le composizioni accettano percorsi delle immagini: non dipendono dal dominio del catalogo.

```tsx
import '@sft/design-system/styles.css';
import { Button, StatusBadge } from '@sft/design-system';

export function Example() {
  return <><Button>Salva</Button><StatusBadge tone="warning">In corso</StatusBadge></>;
}
```

La libreria usa React 19. Il CSS compilato contiene le classi Tailwind utilizzate e i font web. I token sono anche esportati separatamente come `@sft/design-system/tokens.css`. Verifica eventuali conflitti di stile nella singola applicazione prima della migrazione.

## Asset e Canva

Gli SVG locali restano i master fedeli. Le immagini sono fotografie reali già presenti nel sito; le nuove grafiche sono vettoriali. Non sono state inventate immagini di barche o risultati sportivi. Provenienza e licenze sono in `LICENSES/ASSET_PROVENANCE.md`.

Canva ha creato nove design con testo modificabile. Le correzioni dei testi sono in bozze temporanee, in attesa di approvazione richiesta dal connettore prima del salvataggio. I font possono essere sostituiti dalla conversione: controlla i master nell’editor prima di distribuirli. I link firmati delle anteprime sono temporanei; i link editor sono disponibili nel registro JSON.

## Limiti della consegna

Sito e CRM non sono stati migrati. Il kit non è pubblicato in un registro npm. Non è una certificazione completa di accessibilità: verifica ogni schermata e ogni composizione finale. Il bundle del catalogo include il codice sorgente da consultare; il bundle della libreria resta separato.

## Next.js

Per adottare il kit gradualmente con Tailwind 3 importa `@sft/design-system/styles.next.css` e aggiungi `.sft-root` solo alle aree migrate. I font sono forniti da next/font/local. Le composizioni statiche sono disponibili da `@sft/design-system/identity`. I portal devono avere un proprio contenitore di tema; non sono usati nel primo incremento del sito.
