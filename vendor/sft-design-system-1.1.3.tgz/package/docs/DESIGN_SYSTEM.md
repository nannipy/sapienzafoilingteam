# Sapienza Foiling Team Design System

Versione 1.1.1 · 13 ottobre 2026

Questo documento definisce l’identità visiva, i componenti web e i materiali di comunicazione di Sapienza Foiling Team. Il riferimento è il sito esistente: logo SFT, bordeaux, Kelson, Geist e fotografie del progetto. La libreria è un progetto separato: l’adozione nel sito e nel CRM avviene per schermate, dopo verifica.

![La barca del team in volo](./brand/photos/boat-flight.jpg)

## Il carattere del sistema

Il team progetta, costruisce e naviga. La comunicazione deve mostrare questo lavoro attraverso fotografie autentiche, dettagli delle lavorazioni, dati contestualizzati e testi comprensibili. La grafica accompagna le informazioni: evita risultati inventati, fotografie di barche generiche e affermazioni tecniche prive di una fonte.

La firma visiva nuova è una famiglia di linee di flusso: un motivo astratto, ispirato al movimento dell’acqua e al foil. È disponibile in SVG su bordeaux, chiaro e scuro. È decorativo, non rappresenta una simulazione CFD. Compare sulle copertine e sui fondi editoriali; non entra in moduli, tabelle o grafici.

![Pattern di flusso su bordeaux](./brand/patterns/flow-burgundy.svg)

## Marchio

La geometria del marchio è conservata dal master SVG del sito. Il master mantiene anche i suoi colori originali; gli export monocromatici normalizzano il bordeaux a `#822433`. Le varianti disponibili sono originale, bordeaux, bianco e ink. La composizione orizzontale BrandLockup affianca al simbolo il nome Sapienza e il descrittore Foiling Team, Workspace o Design system.

![Marchio bordeaux](./brand/logos/sft-burgundy.svg)

Lascia un’area libera almeno pari a un quarto della larghezza del simbolo. Nel digitale il simbolo non deve scendere sotto 24 px in larghezza; per favicon o miniature sotto questa misura va verificata una variante dedicata. Il lockup standard usa un simbolo largo 36 px e alto 48 px. Usa la variante bianca sulle superfici scure e la variante bordeaux su chiaro. Non deformare, ruotare, applicare ombre o usare il simbolo come trama. Le linee di flusso restano separate dal logo.

## Colori

| Ruolo | Valore | Uso |
| --- | --- | --- |
| Bordeaux | `#822433` | Identità, azione principale su chiaro |
| Bordeaux scuro | `#6b1d28` | Superfici di comunicazione e accenti scuri |
| Accento bordeaux | `#a34252` | Motivi grafici e accenti secondari |
| Void | `#0a0808` | Fondi scuri e immagini immersive |
| Carbon | `#141212` | Superfici secondarie scure |
| Paper | `#fffcfd` | Sfondo chiaro |
| Ink | `#1a1718` | Testo principale su chiaro |
| Oro | `#f2c572` | Accento di comunicazione, ripreso dalla famiglia social; non azione primaria |

I componenti consumano token semantici. `primary` e `primary-foreground` sono una coppia superficie/testo; `muted` è una superficie, `muted-foreground` è testo secondario. Questo differisce dal CSS attuale del CRM e richiede una migrazione esplicita. I valori light e dark sono salvati in `public/brand/tokens.json` e in `src/tokens.css`.

Sul tema scuro l’accento funzionale primary diventa `#efadba` con testo `#381017`: non è una nuova tinta del logo, ma una soluzione per leggibilità. Successo, warning, informazioni ed errori usano coppie dedicate per entrambi i temi. Non comunicare un esito solo con il colore: aggiungi sempre una parola o un’icona con significato comprensibile.

Non applicare bianco su oro. Usa ink sull’oro. Non usare il colore di un reparto come identità alternativa del team: nel sistema iniziale i reparti sono riconoscibili dal nome e dall’icona.

## Tipografia e font

| Famiglia | Ruolo | Pesi e regole |
| --- | --- | --- |
| Kelson | Titoli, copertine, nome del team | 700–800; maiuscolo per copertine brevi, frase normale per titoli interni |
| Geist | Testo, etichette, controlli, descrizioni | Variabile; 400 lettura, 500–600 etichette |
| Geist Mono | Dati, unità, timestamp e metadati tecnici | Variabile; numeri tabulari e unità esplicite |

Non utilizzare Syne, Avenir o Georgia come eccezioni implicite. Il nome del ruolo è display, sans o mono; il vecchio alias `font-syne` del sito va sostituito quando le schermate vengono migrate.

Scala: 12 px metadati brevi; 14 px UI densa; 16 px testo standard; 20 px introduzioni; 24 e 32 px titoli di sezioni; 40–88 px titoli editoriali fluidi. Su mobile il display si riduce senza diminuire il testo di lettura sotto 16 px nei contenuti lunghi. I campi di testo mobile usano almeno 16 px. Interlinea 1.55–1.7 per i testi, 1.03–1.15 per titoli display. Mantieni la lettura entro circa 65 caratteri per riga.

WOFF per web e OTF/TTF per strumenti di impaginazione sono nella cartella font. Il CSS usa `font-display: swap`. I font esistenti sono stati raccolti, non disegnati da zero. Geist e Geist Mono mantengono la loro licenza; nella raccolta locale non è presente la licenza Kelson, quindi non viene attribuito un diritto di redistribuzione pubblica non verificato.

## Spazi, superfici e layout

Scala comune: 4, 8, 12, 16, 24, 32, 48, 64, 96 px. Usa 8–12 px tra etichetta e controllo, 16–24 px tra gruppi, 32–48 px tra blocchi e 64–96 px tra sezioni pubbliche. Le tabelle possono essere più dense dei contenuti editoriali.

Raggi: 8 px per controlli, 10 px come raggio base delle superfici UI, 16–24 px per superfici editoriali e pillola per CTA promozionali. Evita di aggiungere raggi intermedi per singole pagine. Un bordo tenue delimita le superfici; le ombre sono riservate a menu, popover e dialoghi.

Breakpoint di riferimento: 640, 768, 1024, 1280 px. Il catalogo passa da navigazione laterale a navigazione orizzontale su mobile. Il contenuto principale si restringe, le card diventano una colonna e le tabelle mantengono uno scorrimento orizzontale interno. Il comportamento mobile viene progettato per componente, non affidato a una riduzione dell’intera schermata.

## Icone e movimento

Lucide è la famiglia condivisa: griglia 24 px, tratto 2 px. Le icone decorative hanno `aria-hidden`; un controllo con sola icona ha un nome accessibile. Non usare le icone come sostituti delle etichette nelle azioni ambigue.

Durate di riferimento: 120 ms feedback breve, 180 ms cambi di stato, 320 ms ingresso editoriale. Non animare costantemente le interfacce operative. Il sistema rispetta `prefers-reduced-motion`. Il focus deve essere visibile e conservato dopo chiusura di dialoghi e menu.

## Componenti di base

La distribuzione contiene i componenti shadcn ufficiali, con token SFT e modifiche mirate. Il catalogo mostra le principali composizioni; l’appendice include il codice integrale di ogni file e delle dipendenze locali. I componenti Radix mantengono gestione del focus e interazione da tastiera.

| Famiglia | Componenti |
| --- | --- |
| Azioni | Button, Toggle, ToggleGroup |
| Campi | Input, Textarea, Label, Field, Checkbox, Switch, RadioGroup, Select |
| Contenitori | Card, Separator, AspectRatio, ScrollArea, Collapsible |
| Navigazione | Breadcrumb, NavigationMenu, Sidebar, Tabs, Pagination |
| Overlay | Dialog, AlertDialog, Sheet, Popover, Tooltip, DropdownMenu |
| Feedback | Alert, Badge, Empty, Skeleton, Spinner, Progress, Toaster |
| Dati e scelta | Table, Calendar, Command, Slider |

Button standard è alto 44 px, la dimensione grande 48 px. Le dimensioni compatte derivano da shadcn e sono destinate a layout densi, non alle azioni principali touch. La variante `brand` usa pillola, maiuscolo e spaziatura marcata. `destructive` è dedicata a operazioni di rimozione; non rappresenta il semplice “Annulla”. `ActionButton` disabilita il controllo durante il caricamento e imposta `aria-busy`.

Input e Textarea devono avere un’etichetta. Il placeholder è un esempio, non sostituisce l’etichetta. Associa il messaggio di errore con `aria-describedby`, marca il campo con `aria-invalid` e spiega la correzione necessaria. Nel catalogo il form usa anche la validazione HTML; le regole di dominio rimangono nel progetto.

Dialog mostra un titolo e una descrizione; AlertDialog rende esplicita una conferma. Il codice di archivio nel catalogo è dimostrativo e non agisce sui dati. Tooltip integra un’etichetta comprensibile e non contiene informazioni indispensabili all’uso del controllo.

Skeleton si usa quando la struttura è prevedibile, Spinner per attese brevi e Empty quando il caricamento è terminato senza risultati. Non mostrare “Nessun risultato” mentre la richiesta è ancora in corso. Toast conferma un esito; errori persistenti e problemi dei campi restano anche vicino al contenuto interessato.

## Composizioni SFT

| Composizione | Funzione e dati |
| --- | --- |
| BrandLockup | Simbolo, nome e descrittore; base degli asset configurabile |
| Hero | Foto reale, titolo, descrizione e CTA; livello heading configurabile |
| PageHeader | Contesto, titolo, descrizione e azioni |
| DepartmentCard | Nome, icona, descrizione e link facoltativo del reparto |
| StatusBadge | Stato testuale e tono semantico |
| Metric | Valore, unità ed eventuale contesto |
| EmptyState | Titolo, spiegazione e azione successiva |
| SponsorGrid | Loghi forniti dall’applicazione; nome e link di ogni partner |
| ContentCard | Scheda evento o articolo con fotografia, descrizione e metadati |
| ActivityItem | Attività e data in formato leggibile e machine-readable |
| ComboBox | Selezione ricercabile, etichetta e valore controllato |
| DatePicker | Data locale, calendario e testo italiano |
| DataTable | Ricerca, ordinamento, paginazione e stato senza risultati |
| LineChart | Serie semplice, unità e descrizione testuale dei valori |
| SocialTemplate | Anteprima responsive di post, story o slide |

I componenti non chiamano Supabase, Google o API applicative. Le applicazioni passano dati, callback e link. La tabella è un pattern concreto per attività, non un motore universale per ogni schema; nuovi schemi si aggiungono con API progettate e verifiche. Il grafico è adatto a una serie semplice: i grafici di telemetria multiserie richiedono ulteriori componenti specializzati. Gli editor documentali del CRM restano componenti applicativi, da integrare con le fondazioni senza riscriverne automaticamente il comportamento.

## Esempio di utilizzo

```tsx
import { ActionButton, DepartmentCard, departments } from '@sft/design-system';
import '@sft/design-system/styles.css';

export function Reparti() {
  return (
    <section className="sft-root">
      <h1>Reparti del team</h1>
      <DepartmentCard department={departments[5]} href="/team/elettronica" />
      <ActionButton onClick={() => console.log('Salva nel progetto')}>
        Salva modifiche
      </ActionButton>
    </section>
  );
}
```

I pacchetti includono CSS compilato e font referenziati dal CSS. Per BrandLockup, Hero e gli altri componenti con immagini, copia `public/brand` nell’area statica del progetto e passa `assetBase` quando il percorso cambia. La distribuzione è ESM per React 19 e segna l’entry come client per i progetti Next. Nel catalogo il preflight è importato separatamente; la libreria non forza il reset globale. I componenti hanno classi di utilità già compilate; le classi aggiunte dal progetto consumatore devono essere generate dal suo ambiente. Un progetto con Tailwind 3 può usare il CSS compilato; l’interazione con le sue classi e con le vecchie variabili va verificata prima dell’adozione.

## Fotografia e asset

![Il lavoro del team nel paddock](./brand/photos/workshop.jpg)

Le sei fotografie della raccolta sono copiate dal sito senza ritocco: barca dall’alto, volo, squadra, lavoro nel paddock, dettaglio della barca e vela con partner. I crop del catalogo e dei template sono scelte di impaginazione. Mantieni il soggetto leggibile e colloca i testi in zone tranquille; un overlay deve migliorare il contrasto senza nascondere il lavoro.

Non cambiare loghi presenti sulle vele né inserire sponsor in fotografie. Mantieni i crediti quando identificati. La raccolta di provenienza non certifica automaticamente i diritti di pubblicazione di ogni foto. I loghi partner nel catalogo sono esempi presi dal sito, non una nuova attestazione di accordi attivi.

## Template per la comunicazione

I template sono una famiglia coordinata: fotografia o fondo bordeaux, logo in alto, titolo Kelson, testo Geist, metadati e chiusura Geist Mono. Le linee di flusso accompagnano le spiegazioni tecniche. L’oro è un accento limitato; il nome del partner resta nel suo marchio originale.

| File | Formato di lavoro | Uso |
| --- | --- | --- |
| update.svg | 1080 × 1350 | Aggiornamento di progetto |
| recruiting.svg | 1080 × 1350 | Reparti e partecipazione al team |
| technical.svg | 1080 × 1350 | Spiegazione tecnica |
| event.svg | 1080 × 1350 | Evento, regata o trasferta |
| sponsor.svg | 1080 × 1350 | Partner e collaborazione |
| carousel-body.svg | 1080 × 1350 | Slide interna di un carosello |
| story.svg | 1080 × 1920 | Story con margini prudenti |
| presentation.svg | 1920 × 1080 | Copertina presentazione |
| presentation-content.svg | 1920 × 1080 | Slide contenuti e fotografia |

Queste sono dimensioni scelte per il kit, non una dichiarazione dei requisiti universali delle piattaforme. Prima della pubblicazione controlla ritaglio, preview e sovrapposizioni dell’interfaccia nell’app destinataria. Non collocare informazioni indispensabili vicino ai bordi o dietro pulsanti e didascalie.

![Template aggiornamento](./templates/update.svg)
![Template tecnico](./templates/technical.svg)
![Template presentazione](./templates/presentation.svg)

Per i post il margine base è 80 px, il titolo non supera 7 parole e il testo breve resta entro circa 35 parole. Le slide interne hanno un titolo, un paragrafo e una sola idea. Il template sponsor contiene segnaposto visibili: sostituiscili con i nomi e i loghi approvati. Le presentazioni devono restare leggibili a distanza: evitare paragrafi più lunghi del template e microtesti nei grafici.

Gli SVG sono sorgenti locali modificabili con testo separato. Gli export PNG sono anteprime. La conversione in un design Canva può modificare font, raggruppamenti e spaziature: ogni link creato viene elencato in `communication/canva-designs.json` con il suo stato di verifica. Se il link non è presente, il template è disponibile localmente e non è stato creato nell’account Canva. Il documento non presume che l’import SVG crei automaticamente tutti gli elementi testuali modificabili in Canva.

Sono stati creati nove design Canva con elementi testuali modificabili, verificati attraverso il contenuto restituito dal connettore. Le correzioni a maiuscole e nomi del team sono preparate in transazioni temporanee e attendono approvazione prima del salvataggio. [Rivedi le bozze Canva](./communication/canva-review.html). La fedeltà di font e posizionamento richiede verifica nell’editor; non è attestata dalla sola estrazione del testo.

### Ricostruzione e manutenzione in Canva

Carica Kelson OTF e i font di impaginazione dove il piano e la licenza lo consentono; verifica disponibilità delle famiglie e dei pesi. Imposta palette con i valori del kit. Duplica il template per ogni contenuto. Mantieni fissi marchio, margini e gerarchia; modifica fotografia, titolo, paragrafo e metadati. Se una conversione introduce una sostituzione tipografica, correggila prima di usare il template come master.

Non esiste una sincronizzazione automatica dei token con Canva. Ogni aggiornamento del sistema richiede un controllo dei template e un numero di versione. I font OTF/TTF servono per impaginazione; i file WOFF sono risorse web, non sostituti universali per il caricamento nei diversi strumenti.

## Voce, nomi e lingue

Nome completo: Sapienza Foiling Team. Abbreviazione: SFT. Barca: Meravijosa. Competizione: SuMoth Challenge. Il sistema usa i nomi dei reparti del CRM al 13 ottobre 2026; prima di modificare il nome di un reparto occorre allineare anche social, sito e documenti. In particolare il nome corrente Elettronica e Software deve essere confrontato con i materiali storici Elettronica e Data Analysis.

Il sito spiega il progetto alle persone esterne; i social raccontano un lavoro, una persona o un risultato concreto; il CRM indica le azioni da svolgere. Il tono cambia per pubblico, ma i fatti restano gli stessi. Le versioni IT/EN mantengono il significato. Le unità e i valori hanno una fonte; i dati dimostrativi del catalogo non diventano prestazioni pubbliche.

Scrivi “Salva attività”, “Modifiche salvate”, “Salvataggio non riuscito. Riprova.” Evita “Invia” quando non è chiaro cosa accade, successi generici e frasi enfatiche senza contenuto. Non rendere attuale un evento passato né un recruiting scaduto.

## Accessibilità e stati

Verifica contrasto delle coppie testo/sfondo, navigazione da tastiera, focus e nomi dei controlli. Le immagini informative hanno alt; logo ripetuto e foto puramente decorative hanno alt vuoto. Gli heading seguono la struttura della pagina. Un componente include default, hover, focus, disabled e gli stati applicabili di caricamento, errore e assenza di dati.

La cartella tests verifica comportamenti, non soltanto la presenza delle classi: tabella con ricerca e paginazione, dialog con Esc e ritorno del focus, scelta dei reparti, calendario e contrasto delle coppie semantiche. Il rapporto finale distingue test automatici e verifica visuale. Non è dichiarata una certificazione WCAG completa del sito o del CRM.

## Adozione e versioni

Installa la release locale con il tarball nella cartella release, importa il CSS e usa i componenti pubblici. Non copiare la stessa implementazione in ogni progetto: aggiorna la versione del pacchetto. I sorgenti shadcn sono conservati per manutenzione e tracciabilità; personalizzazioni comuni vengono fatte nella libreria.

Migra prima controlli e token, poi una schermata pubblica e una del CRM, quindi pattern complessi. Non sostituire subito tutti gli stili del CRM: la sua variabile muted e il suo CSS globale hanno significati diversi. Le release devono indicare componenti cambiati, migrazione necessaria e verifica nei progetti. Per app React Native condividi token e specifiche, non componenti DOM.

Un responsabile tecnico mantiene la libreria e un referente comunicazione controlla i template. I nomi delle persone non sono stati assegnati. La versione 1.1.1 include l’adattatore Next e l’hero editoriale. La homepage e la navigazione del sito sono migrate localmente; pagine interne, admin e altri prodotti restano nel piano di adozione. Il catalogo usa esempi dimostrativi ed è consultabile senza accedere ai dati del team.

## Riferimenti e provenienza

[Installazione shadcn con Vite](https://ui.shadcn.com/docs/installation/vite), [token del tema](https://ui.shadcn.com/docs/theming) e [registry](https://ui.shadcn.com/docs/registry). Codice shadcn/ui: licenza MIT. Le condizioni degli altri pacchetti restano quelle dei rispettivi autori. La provenienza dei font, delle foto e del logo è conservata in `LICENSES/ASSET_PROVENANCE.md`.

### Integrazione graduale con Next e Tailwind 3

Importa `@sft/design-system/styles.next.css` dopo il CSS esistente. Gli stili del kit sono limitati alle aree `.sft-root` e non includono font-face: Next continua a gestire Geist e Kelson. Non aggiungere `.sft-root` al body finché tutte le pagine non sono migrate. I contenuti trasferiti in un portal richiedono un contenitore `.sft-root` separato; questa prima adozione usa controlli senza portal. L’ingresso `@sft/design-system/identity` esporta BrandLockup ed EditorialHero senza imporre use client; le pagine server mantengono fetch e dati sul server.

## Appendice Codice dei componenti

La versione completa del documento aggiunge qui i sorgenti effettivi della libreria. Sono disponibili anche nel file component-code.md e nei riquadri del catalogo. L’appendice è generata durante la compilazione: corrisponde ai componenti consegnati.


## Superfici e navigazione — revisione 1.1.2

Le superfici chiare e le card si separano con ombre morbide (`--sft-shadow-surface`, `--sft-shadow-floating`), senza contorni netti. I bordi restano per campi, focus e separatori funzionali. Il marchio SFT sul rosso usa il bianco, senza giallo decorativo. La navbar pubblica si compatta dopo 64 px di scorrimento e torna estesa sotto 24 px; il menu mobile aperto mantiene lo spazio completo. Rispettare la preferenza di movimento ridotto.
