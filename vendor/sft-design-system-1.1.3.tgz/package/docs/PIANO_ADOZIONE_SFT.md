# Piano di adozione del Design System SFT
Data: 13 ottobre 2026. Stato: primo incremento implementato localmente (integrazione, homepage, navigazione e cookie banner); restano pagine interne, flussi e admin.

## Obiettivo e perimetro
Portare identità, gerarchie, controlli e stati del Design System SFT su tutte le interfacce del team. Il primo progetto è il sito pubblico Sapienza Foiling Team, inclusi login e area amministrativa. Il sito diventa il riferimento verificato per l'adozione successiva nel CRM, nel Telemetry Lab, nell'app mobile e nei materiali di comunicazione.

Sito: `02_Software/Sito_Web/sapienza-foiling-team`.
Libreria: `02_Software/Design_System/sft-design-system`.

Il risultato deve preservare contenuti, percorsi, traduzioni IT/EN, moduli, gestione degli articoli/eventi/posizioni/media e comportamento delle integrazioni. Il sistema fornisce presentazione e interazione; Supabase, autenticazione, Google Forms, consensi e analytics restano responsabilità del sito.

## Evidenze attuali e decisioni
L'inventario è stato verificato nei sorgenti locali. Questo turno non ha riesaminato visivamente tutte le pagine né verificato il sito in produzione.

| Evidenza | Implicazione nel piano |
| --- | --- |
| Sito Next.js 16, React 19 e Tailwind 3.4; kit React 19 e Tailwind 4 | Integrare prima una pagina pilota; non assumere che importare il CSS compilato basti. |
| `app/fonts.ts` già usa next/font/local per Geist, Geist Mono e Kelson | Riutilizzare il caricamento Next, evitare il download duplicato dei font incorporati nel kit. |
| `tailwind.config.js`: alias `font-syne` collegato a Kelson | Introdurre nomi per ruolo, poi eliminare gradualmente l'alias fuorviante e aggiornare la vecchia documentazione. |
| `globals.css`: `premium-form-theme` con numerose regole !important | Rimuovere le regole per famiglia di moduli dopo aver verificato gli equivalenti nuovi. |
| `PageLayout` impone cornice bordeaux, pannello bianco e padding; `PageHero` impone altezza 70vh, blur e pattern | Sostituire con composizioni editoriali esplicite, senza applicare lo stesso hero a ogni pagina. |
| `HeroSection` ha carosello, gradienti e due h1 | Definire un solo h1 e una gerarchia leggibile; mantenere la fotografia visibile con contrasto locale sul testo. |
| `admin/globals.css` contiene adattamenti per classi blu/indigo e controlli | Migrare l'admin dopo i controlli comuni; togliere le correzioni solo quando gli elementi destinatari sono migrati. |
| EventForm usa react-datepicker; ArticleAdmin usa un editor Markdown | Adattare questi controlli alle esigenze reali: il DatePicker base del kit non è una sostituzione automatica di ogni campo data/ora. |
| Navbar e Footer si nascondono su /admin | Conservare questa separazione tra sito editoriale e area operativa. |
| Il pacchetto della libreria ha un ingresso con use client e CSS compilato con utility generiche | Prevedere ingressi distinti per parti statiche e interattive e controllare sovrapposizioni di classi CSS. |
| Presenti file non tracciati in docs/blog e public/blog | Preservarli e tenere la migrazione distinta dai materiali già presenti. |

## Regole visive da applicare
- Bordeaux #822433 come colore identitario; toni chiari/scuri e colori di stato con ruoli semantici.
- Kelson per titoli, Geist per lettura e controlli, Geist Mono per dati e metadati.
- Fondo chiaro per lettura e amministrazione; superfici scure e bordeaux per sezioni editoriali mirate. Nessun nuovo cambio tema globale nella prima adozione.
- CTA promozionali con variante brand; azioni di form e admin con varianti operative.
- Fotografie reali, soggetto leggibile e contrasti locali. Per il sito, estendere Hero con una composizione a pannello bordeaux; non trasferire automaticamente il gradiente del catalogo sopra tutta la foto.
- Spaziatura e raggi del sistema, griglie responsive, icone Lucide coerenti.
- Testi lunghi e traduzioni inglesi devono reggere senza tagli; nessun cambio arbitrario della denominazione dei reparti.
- Animazioni brevi, non necessarie alla comprensione e rispettose di reduced motion.

## Come rendere il riuso effettivo
La libreria rimane la fonte comune. Evitare di copiare i quaranta componenti nel sito per poi modificarli autonomamente.

Preparare nella libreria:
1. Un export CSS per l'integrazione con font già gestiti da Next e un export degli stili delle composizioni.
2. Ingressi distinti per controlli interattivi e composizioni statiche, verificati nel build Next. Conservare i fetch e le pagine server sul server.
3. Una strategia verificata per le utility: isolamento delle utility nelle aree .sft-root, mantenendo inizialmente Tailwind 3 nel sito. Impedire che le utility Tailwind 4 generiche ridefiniscano quelle esistenti.
4. Un adattatore dei font che punti alle variabili di next/font/local già presenti.
5. Varianti necessarie per hero editoriale, campi di form e immagini ottimizzate, aggiunte solo dove il sito dimostra un'esigenza.
6. Percorsi asset assoluti dalla radice del sito, ad esempio /brand/logos/sft-burgundy.svg. Il default relativo ./brand della libreria va sostituito nelle pagine annidate.

L’isolamento dei selettori nelle aree .sft-root è la scelta verificata per la migrazione graduale. Se il pilota dimostra che gestire due pipeline di utility è troppo oneroso, rivalutare una migrazione del sito a Tailwind 4 come intervento separato. Non lasciare convivere stili generici in conflitto come soluzione permanente.

Installare una versione locale identificabile del pacchetto; verificare il flusso di dipendenze già usato dal repository (è presente bun.lock) e mantenere un lockfile autorevole. Creare adapter locali sottili per Next Link, Next Image e testi tradotti: non duplicare le regole di design.

## Sequenza di lavoro e criteri di passaggio

| Lotto | Lavoro | Risultato verificabile prima del lotto successivo |
| --- | --- | --- |
| 0 — Baseline | Inventario dei percorsi, screenshot, stati e flussi; esecuzione delle verifiche già disponibili; registrazione dello stato Git | Lista dei problemi preesistenti, screenshot desktop/mobile e mappa dei componenti |
| 1 — Integrazione | Export e isolamento CSS, adapter font/asset, confini server/client; pagina pilota interna non indicizzata | Build Next riuscita; niente doppio caricamento font, utility in conflitto o regressioni sulle pagine non migrate |
| 2 — Navigazione e homepage | Navbar, menu mobile, Footer, HeroSection, FleetShowcaseSection, EventsSection, CTA; stile di cookie banner e popup recruiting | Homepage e navigazione IT/EN coerenti; menu e modali accessibili; dati eventi e link preservati |
| 3 — Pagine editoriali | Team/reparti, barca, sponsor, elenco blog, articolo, contatti e privacy | Tutte queste pagine adottano composizioni comuni con contenuti reali e immagini leggibili |
| 4 — Flussi pubblici | Career, name-on-wings, SignatureForm, PresentationForm, login | Validazione, feedback, consenso, invio e accesso funzionano come prima con il nuovo stile |
| 5 — Area admin | Shell/header, liste, filtri, azioni, editor, eventi, posizioni, bozze e media | Intero percorso amministrativo verificato con accesso autorizzato e dati di prova |
| 6 — Consolidamento | Rimozione stili obsoleti, aggiornamento documentazione e catalogo, verifica completa e preparazione rilascio | Un sistema adottato, registro delle eccezioni, report finale e rollback praticabile |

Ogni lotto deve essere una modifica autonoma e revisionabile. La navigazione globale del lotto 2 influenza anche pagine ancora da migrare: includerle nei controlli di regressione. Non rimuovere classi o componenti solo perché non compaiono nella homepage.

## Mappa del sito: cosa sostituire

| Percorso / area | Sorgenti principali | Componenti o composizioni di destinazione |
| --- | --- | --- |
| Tutto il sito pubblico | app/layout.tsx, Navbar, Footer, ClientModals | BrandLockup, Button, Sheet/Dialog, navigazione e footer editoriali |
| / | app/page.tsx, HeroSection, FleetShowcaseSection, EventsSection, CallToActionSection | Hero editoriale, schede barca, ContentCard evento, CTA brand |
| /team | TeamClientPage, TeamHero, DepartmentFilter, DepartmentCard, DepartmentDetail | Hero compatto, Tabs/filtri, DepartmentCard adattata ai dati esistenti, dettaglio reparto |
| /boat | BoatClientPage | Hero, sezioni tecniche, schede Metric con valori reali e unità, galleria |
| /sponsor | SponsorClientPage | SponsorGrid e CTA; conservare colori, proporzioni e categorie dei marchi partner |
| /blog | BlogClientPage | PageHeader, schede articolo, filtri, paginazione, EmptyState |
| /blog/[id] | ArticleClientPage, ShareButtons | Layout articolo, tipografia di lettura, metadata, condivisione, immagini e didascalie |
| /career | CareerClientPage, OpenPosition | Schede posizione, Accordion FAQ e CTA verso il modulo esistente |
| /contact | ContactClientPage | PageHeader, schede contatto e link mail/social esistenti |
| /name-on-wings | NameOnWingsClientPage, SignatureForm, PresentationForm | Composizioni editoriali, Field/Input/Checkbox/Select, ActionButton, messaggi di esito |
| /privacy-policy | PrivacyPolicyClient | Layout documento e tipografia; preservare integralmente il contenuto informativo |
| /login | login/page.tsx | Card, Field, Input, ActionButton, Alert; conservare redirect e gestione sessione |
| /admin | AdminShell, AdminHeader, admin/page.tsx, ArticleAdmin | Shell operativa, intestazione, liste/stati/azioni; adattatore dell'editor Markdown |
| /admin/drafts | admin/drafts/page.tsx | Elenco bozze, Badge, menu azioni, EmptyState e Dialog di conferma |
| /admin/media | admin/media/page.tsx | Griglia media, controlli upload, selezione e feedback; non comprimere né cancellare asset esistenti |
| /admin/events e /new, /[id]/edit | pagine eventi, EventForm | Liste e filtri, Field, Select, adapter data/ora, upload e conferma operazioni |
| /admin/positions e /new, /[id]/edit | pagine posizioni, PositionForm | Liste, moduli con stati, azioni operative e conferme |

Inventario: 20 file page.tsx, di cui 9 nell'area admin. I percorsi dinamici vanno verificati con contenuti brevi, lunghi e assenti, non solo con un elemento.

La DataTable del kit è attualmente specifica per attività. Le liste articoli/eventi/posizioni richiedono un'API per colonne e azioni oppure composizioni dedicate: non forzare i modelli del sito nel tipo ActivityRow.

## Verifiche per ogni lotto
Prima: screenshot e controllo dei flussi interessati. Dopo:
- Desktop 1440 px, tablet 768 px, mobile 390 px e 320 px; niente overflow involontario, controlli leggibili e aree tocco adeguate.
- IT e EN; contenuti e titoli lunghi, assenza di dati, loading, errori, disabled e successo.
- Tastiera, focus visibile, chiusura dei modali, ritorno del focus, un h1 principale per pagina, label e messaggi associati ai campi.
- Contrasto nelle composizioni finali, comprese testo/fotografia e superfici inverse. I test del kit non coprono automaticamente tutte le pagine del sito.
- Nessun doppio caricamento font; immagini ottimizzate e proporzioni stabili; confrontare LCP/CLS e JavaScript con la baseline, senza inventare numeri prima di misurarli.
- Build e TypeScript; test Jest pertinenti già presenti. Aggiornare i test di comportamento quando cambia l'interazione, senza sostituirli con soli snapshot di stile.
- Verificare lo script lint prima di usarlo come gate: attualmente è configurato come next lint; validare la sua disponibilità nella versione Next installata e adeguarlo se necessario.
- Per form, login e admin: verifica manuale dei flussi con sessione autorizzata e dati di prova. Nessun invio o cancellazione di dati reali come semplice prova visuale.
- Metadati SEO, canonical, sitemap, link, revalidate e fetch server preservati.
- Consensi, popup recruiting, eventi analytics e tracciamento dei link conservano il comportamento previsto.

## Prima consegna operativa
Il primo incremento comprende lotti 0 e 1, poi homepage e navigazione del lotto 2. Mostra:
- Un'anteprima del sito con navbar, footer e homepage, in IT/EN, desktop/mobile.
- La versione della libreria effettivamente utilizzata e gli adattatori aggiunti.
- Il report di confronto visivo e delle verifiche.
- Le pagine ancora da migrare e le eccezioni temporanee esplicite.

I controlli pubblici di consenso e recruiting devono funzionare anche se le loro pagine di destinazione sono migrate in un lotto successivo.

## Adozione nelle altre interfacce
1. CRM: verificare inventario e comportamento autenticato, poi token/font, shell e navigazione, liste/moduli e dashboard. Preservare provider persistenti, stato, cache e integrazioni; dimensioni più dense dove utili.
2. Telemetry Lab: token e tipografia, controlli, grafici/unità/legende e stati di connessione. Il codice React web può essere condiviso dove compatibile; i grafici specifici restano adapter del prodotto.
3. App mobile: verificare tecnologia e schermate; condividere token, asset e gerarchie con un adapter per la piattaforma. Non assumere che CSS o componenti DOM siano riutilizzabili direttamente.
4. Comunicazione: consolidare i master Canva e aggiornare template social/presentazioni con la stessa versione delle fondazioni. Non esiste una sincronizzazione automatica con i token web.

Questa sequenza evita di replicare negli altri prodotti problemi di integrazione ancora aperti nel sito. Il censimento dettagliato degli altri prodotti è parte dei rispettivi lotti, non è completato da questa mappa del sito.

## Manutenzione e rilascio
Un referente tecnico mantiene libreria e adapter, un referente comunicazione mantiene i template: le persone sono da assegnare. Le eccezioni devono indicare componente, motivo e criterio per il rientro.

Ogni rilascio registra: versione della libreria, pagine migrate, test effettuati, problemi noti e screenshot. Le modifiche comuni tornano nel catalogo; i dettagli di dominio restano nel sito. Archiviare la vecchia guida SAPIENZA_DESIGN_SYSTEM.md solo dopo aver trasferito le regole ancora valide e aggiornato i riferimenti.

Preparare una preview revisionabile prima del rilascio in produzione. Verificare che la versione precedente sia ripristinabile e conservare il precedente pacchetto/CSS. Il rollback riguarda codice e stili; questa migrazione non richiede modifiche allo schema dei dati.

## Definizione di completamento del sito
Il sito è migrato quando tutte le 20 pagine dell'inventario e le loro composizioni globali usano il sistema o hanno un'eccezione documentata; i flussi pubblici e amministrativi sono verificati; non restano font, varianti o componenti duplicati senza motivo; il catalogo corrisponde al codice adottato.

Una homepage coerente completa solo il primo incremento. Accesso admin o verifica produzione non disponibili devono essere riportati come verifiche mancanti, senza dichiarare il sito completamente migrato.
