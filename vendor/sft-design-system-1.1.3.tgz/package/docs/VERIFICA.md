# Verifica della consegna — 13 ottobre 2026

## Aggiornamento 1.1.1

Homepage e navigazione del sito migrate localmente. Build Next riuscita; 35 test del sito e 29 test della libreria superati. L’adattatore Next verifica isolamento degli stili e assenza di font-face; il documento ora comprende 50 file sorgente. Nessun deployment.

## Consegna originaria 1.0.0

Le verifiche seguenti si riferiscono alla prima consegna del kit, prima dell’adozione nel sito.

- Build del catalogo, libreria ESM, dichiarazioni TypeScript e documento: superata.
- Import della libreria compilata e rendering server di Button e StatusBadge: superati.
- 29 test superati: 21 coppie di contrasto testuale nelle modalità chiara e scura, 8 verifiche di comportamento per tabella, caricamento, dialogo, selezione, calendario e grafico.
- Catalogo verificato nel browser a 1280 × 900 e 390 × 844: nessuna immagine mancante; nessuno scorrimento orizzontale della pagina a 390 px. Controllate modalità scura, form e modifica del titolo del template.
- Documento illustrato verificato anche su mobile: 17 sezioni principali, 49 pannelli di codice, nessuna immagine mancante.
- Nove master SVG con testo separato e nove PNG renderizzati attraverso copie con caratteri convertiti in tracciati per mantenere la resa dei font.
- Nove design creati in Canva. Presenza di testo modificabile verificata attraverso il connettore; errori di riconoscimento del marchio corretti nelle bozze. Tutte le anteprime delle bozze caricate correttamente nella pagina di revisione. Correzioni non salvate: il connettore richiede approvazione esplicita dopo la visione dell’anteprima. La conversione Canva può sostituire font e spaziature.
- Nessuna migrazione eseguita sul sito o sul CRM; nessuna pubblicazione del pacchetto.

Il bundle del catalogo include il codice consultabile e pesa circa 788 kB prima della compressione. La libreria separata pesa circa 109 kB di JavaScript e 378 kB di CSS, che incorpora i font. Non sono misure di prestazioni del CRM o una certificazione completa WCAG.
