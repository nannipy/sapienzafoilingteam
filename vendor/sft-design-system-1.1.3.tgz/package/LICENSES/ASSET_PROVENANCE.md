# Provenienza delle risorse

Logo: master SVG del sito SFT, geometria conservata; varianti monocromatiche derivate per gli usi del team. Il colore del master originale non è normalizzato.

Fotografie: copiate senza ritocchi dalla raccolta del sito del team. Non sono immagini generate. La raccolta non stabilisce i diritti di redistribuzione o l'autore di ogni scatto; conservare i crediti dove identificati.

Font: Geist e Geist Mono dal sito esistente; Kelson OTF dalla raccolta Identita_Visiva e WOFF dal sito. Non è stata trovata una licenza Kelson nella raccolta locale. L'inclusione preserva le risorse usate dal team, non concede nuovi diritti per la loro redistribuzione pubblica.

Pattern e template SVG: creati per questo sistema. Componenti UI: shadcn/ui (MIT), con personalizzazioni SFT; Radix e Lucide conservano le loro licenze.
