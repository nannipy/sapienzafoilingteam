import type { ReactNode } from 'react';

export function BrandLockup({assetBase='/brand',inverse=false,label='Foiling Team',className=''}:{assetBase?:string;inverse?:boolean;label?:string;className?:string}) {
 return <span className={`sft-brand ${className}`}><img src={`${assetBase}/logos/${inverse?'sft-white':'sft-burgundy'}.svg`} alt="" width={36} height={48}/><span><strong>SAPIENZA</strong><small>{label}</small></span></span>;
}

export function EditorialHero({eyebrow,title,description,image,actions,caption}:{eyebrow?:string;title:ReactNode;description:string;image:ReactNode;actions:ReactNode;caption?:ReactNode}) {
 return <section className="sft-editorial-hero"><div className="sft-editorial-hero-copy">{eyebrow&&<p className="sft-eyebrow">{eyebrow}</p>}<h1 className="sft-display">{title}</h1><p className="sft-editorial-description">{description}</p><div className="sft-editorial-actions">{actions}</div></div><figure className="sft-editorial-hero-image">{image}{caption&&<figcaption>{caption}</figcaption>}</figure></section>;
}
