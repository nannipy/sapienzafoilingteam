"use client";
import { useId, useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, Check, ChevronsUpDown, Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover,PopoverContent,PopoverTrigger } from '@/components/ui/popover';
import { Command,CommandEmpty,CommandGroup,CommandInput,CommandItem,CommandList } from '@/components/ui/command';
import { Calendar } from '@/components/ui/calendar';
import { Table,TableBody,TableCell,TableHead,TableHeader,TableRow } from '@/components/ui/table';
import { StatusBadge } from './brand';

export function ComboBox({label,value,onChange,options}: {label:string;value:string;onChange:(value:string)=>void;options:readonly {value:string;label:string}[]}) {
 const [open,setOpen]=useState(false);const id=useId();
 return <div className="grid gap-2"><Label id={id}>{label}</Label><Popover open={open} onOpenChange={setOpen}><PopoverTrigger asChild><Button variant="outline" role="combobox" aria-labelledby={id} aria-expanded={open} className="justify-between">{options.find(o=>o.value===value)?.label||'Seleziona'}<ChevronsUpDown aria-hidden="true"/></Button></PopoverTrigger><PopoverContent className="p-0"><Command><CommandInput placeholder="Cerca reparto…" aria-label="Cerca reparto"/><CommandList><CommandEmpty>Nessun reparto trovato.</CommandEmpty><CommandGroup>{options.map(o=><CommandItem key={o.value} value={o.label} onSelect={()=>{onChange(o.value);setOpen(false)}}><Check aria-hidden="true" className={value===o.value?'opacity-100':'opacity-0'}/>{o.label}</CommandItem>)}</CommandGroup></CommandList></Command></PopoverContent></Popover></div>;
}
export function DatePicker({label,value,onChange}: {label:string;value?:Date;onChange:(value:Date|undefined)=>void}) {
 const [open,setOpen]=useState(false); const id=useId();
 return <div className="grid gap-2"><Label id={id}>{label}</Label><Popover open={open} onOpenChange={setOpen}><PopoverTrigger asChild><Button aria-labelledby={id} variant="outline" className="justify-start"><CalendarIcon aria-hidden="true"/>{value?format(value,'d MMMM yyyy',{locale:it}):'Scegli una data'}</Button></PopoverTrigger><PopoverContent className="w-auto p-0"><Calendar locale={it} mode="single" selected={value} onSelect={d=>{onChange(d);setOpen(false)}}/></PopoverContent></Popover></div>;
}
export type ActivityRow={id:string;title:string;department:string;status:'Da iniziare'|'In corso'|'Completato'};
export function DataTable({rows,pageSize=5}: {rows:readonly ActivityRow[];pageSize?:number}) {
 const [query,setQuery]=useState('');const [ascending,setAscending]=useState(true);const [page,setPage]=useState(0);const id=useId();const size=Math.max(1,pageSize);
 const filtered=useMemo(()=>rows.filter(r=>`${r.title} ${r.department} ${r.status}`.toLocaleLowerCase('it').includes(query.toLocaleLowerCase('it'))).sort((a,b)=>ascending?a.title.localeCompare(b.title,'it'):b.title.localeCompare(a.title,'it')),[rows,query,ascending]);
 const pageCount=Math.max(1,Math.ceil(filtered.length/size));const current=Math.min(page,pageCount-1);const visible=filtered.slice(current*size,(current+1)*size);
 return <div><div className="mb-4 flex flex-wrap items-end justify-between gap-3"><div className="grid gap-2"><Label htmlFor={id}>Cerca attività</Label><Input id={id} type="search" value={query} onChange={e=>{setQuery(e.target.value);setPage(0)}} placeholder="Titolo, reparto o stato" className="max-w-sm"/></div><span className="text-sm text-muted-foreground" role="status">{filtered.length} attività</span></div><div className="rounded-lg border"><Table><caption className="sr-only">Attività del team con reparto e stato</caption><TableHeader><TableRow><TableHead aria-sort={ascending?'ascending':'descending'}><Button variant="ghost" onClick={()=>{setAscending(!ascending);setPage(0)}}>Attività{ascending?<ArrowUp aria-hidden="true"/>:<ArrowDown aria-hidden="true"/>}</Button></TableHead><TableHead>Reparto</TableHead><TableHead>Stato</TableHead></TableRow></TableHeader><TableBody>{visible.length?visible.map(row=><TableRow key={row.id}><TableCell className="font-medium">{row.title}</TableCell><TableCell>{row.department}</TableCell><TableCell><StatusBadge tone={row.status==='Completato'?'success':row.status==='In corso'?'info':'neutral'}>{row.status}</StatusBadge></TableCell></TableRow>):<TableRow><TableCell colSpan={3} className="h-28 text-center">Nessuna attività corrisponde alla ricerca.</TableCell></TableRow>}</TableBody></Table></div><nav aria-label="Pagine delle attività" className="mt-4 flex flex-wrap items-center justify-between gap-3"><span className="text-sm text-muted-foreground">Pagina {current+1} di {pageCount}</span><div className="flex gap-2"><Button variant="outline" disabled={current===0} onClick={()=>setPage(current-1)}>Precedente</Button><Button variant="outline" disabled={current>=pageCount-1} onClick={()=>setPage(current+1)}>Successiva</Button></div></nav></div>;
}
export function LineChart({title,points,unit}: {title:string;points:readonly {label:string;value:number}[];unit:string}) {
 const id=useId();const max=Math.max(1,...points.map(p=>p.value));const min=Math.min(0,...points.map(p=>p.value));const range=max-min||1;const x=(i:number)=>48+i*500/Math.max(1,points.length-1);const y=(value:number)=>150-(value-min)/range*120;
 return <figure><figcaption id={id} className="mb-4 text-sm font-medium">{title} <span className="text-muted-foreground">({unit})</span></figcaption>{points.length?<svg viewBox="0 0 600 205" className="sft-chart w-full" role="img" aria-labelledby={id}><desc>{points.map(p=>`${p.label}: ${p.value} ${unit}`).join('; ')}</desc>{[0,.5,1].map(f=><g key={f}><line x1="48" x2="560" y1={150-f*120} y2={150-f*120}/><text x="4" y={154-f*120}>{Math.round(min+range*f)}</text></g>)}<polyline points={points.map((p,i)=>`${x(i)},${y(p.value)}`).join(' ')}/>{points.map((p,i)=><g key={`${p.label}-${i}`}><circle cx={x(i)} cy={y(p.value)} r="4"/><text textAnchor="middle" x={x(i)} y="181">{p.label}</text></g>)}</svg>:<p className="text-sm text-muted-foreground">Nessun dato disponibile.</p>}</figure>;
}
