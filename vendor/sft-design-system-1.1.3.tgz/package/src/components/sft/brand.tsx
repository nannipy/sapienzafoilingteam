import type { ComponentProps, ReactNode } from 'react';
import { ArrowUpRight, Waves, Leaf, Wrench, Wind, Cpu, Anchor, Megaphone, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

import { BrandLockup } from './identity';
export { BrandLockup, EditorialHero } from './identity';
export function ActionButton({loading=false,children,disabled,...props}: ComponentProps<typeof Button>&{loading?:boolean}) {
  return <Button {...props} disabled={disabled||loading} aria-busy={loading||undefined}>{loading&&<Loader2 aria-hidden="true" className="animate-spin"/>}{children}</Button>;
}
export function PageHeader({eyebrow,title,description,actions,level=1}: {eyebrow?:string;title:string;description?:string;actions?:ReactNode;level?:1|2|3}) {
  const Heading=level===1?'h1':level===2?'h2':'h3';
  return <header className="flex flex-wrap items-end justify-between gap-6"><div>{eyebrow&&<p className="sft-eyebrow mb-3 text-primary">{eyebrow}</p>}<Heading className="sft-display text-4xl md:text-5xl">{title}</Heading>{description&&<p className="mt-3 max-w-prose text-muted-foreground">{description}</p>}</div>{actions}</header>;
}
export function Hero({image,alt,title,description,eyebrow,children,level=1}: {image:string;alt:string;title:string;description:string;eyebrow?:string;children?:ReactNode;level?:1|2}) {
  const Heading=level===1?'h1':'h2';
  return <section className="sft-hero"><img src={image} alt={alt} fetchPriority="high"/><div>{eyebrow&&<p className="sft-eyebrow mb-5">{eyebrow}</p>}<Heading className="sft-display">{title}</Heading><p>{description}</p><div className="mt-7 flex flex-wrap gap-3">{children}</div></div></section>;
}
export const departments=[
 {id:'scafo',name:'Scafo e terrazze',description:'Progettazione dello scafo e delle strutture.',icon:Waves},
 {id:'management',name:'Management e Comunicazione',description:'Relazioni, organizzazione e racconto del progetto.',icon:Megaphone},
 {id:'materiali',name:'Materiali e Sostenibilità',description:'Scelta dei materiali e valutazione del loro impatto.',icon:Leaf},
 {id:'manufacturing',name:'Manufacturing e Cantiere',description:'Costruzione, lavorazioni e assemblaggio.',icon:Wrench},
 {id:'foil',name:'Foil e Controllo di Volo',description:'Foil, assetto e regolazione del volo.',icon:Wind},
 {id:'elettronica',name:'Elettronica e Software',description:'Elettronica di bordo e strumenti software.',icon:Cpu},
 {id:'shore',name:'Shore Team e Logistica',description:'Preparazione, logistica e supporto a terra.',icon:Anchor}
] as const;
export function DepartmentCard({department,href}: {department:typeof departments[number];href?:string}) {
 const Icon=department.icon;
 return <Card className="h-full"><CardHeader><Icon className="mb-6 size-7 text-primary" aria-hidden="true"/><CardTitle className="font-display text-2xl">{department.name}</CardTitle></CardHeader><CardContent><p className="text-sm text-muted-foreground">{department.description}</p>{href&&<Button asChild variant="link" className="mt-4 px-0"><a href={href}>Scopri il reparto<ArrowUpRight aria-hidden="true"/></a></Button>}</CardContent></Card>;
}
const tones={neutral:'bg-muted text-muted-foreground',success:'bg-success-soft text-success',warning:'bg-warning-soft text-warning',info:'bg-info-soft text-info',danger:'bg-destructive/10 text-destructive'} as const;
export function StatusBadge({tone='neutral',children}: {tone?:keyof typeof tones;children:ReactNode}) {return <Badge className={cn('border-transparent',tones[tone])}>{children}</Badge>;}
export function Metric({label,value,unit,description}: {label:string;value:string|number;unit?:string;description?:string}) {return <Card><CardContent className="pt-6"><p className="text-sm text-muted-foreground">{label}</p><p className="my-3 font-mono text-3xl font-medium tabular-nums">{value}{unit&&<span className="ml-2 text-base text-muted-foreground">{unit}</span>}</p>{description&&<p className="text-xs text-muted-foreground">{description}</p>}</CardContent></Card>;}
export function EmptyState({title,description,action}: {title:string;description:string;action?:ReactNode}) {return <div className="rounded-xl border border-dashed p-10 text-center"><Waves className="mx-auto mb-4 size-7 text-primary" aria-hidden="true"/><h3 className="font-display text-2xl font-bold">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">{description}</p>{action&&<div className="mt-5">{action}</div>}</div>;}
export function SponsorGrid({sponsors}: {sponsors:readonly {name:string;image:string;href?:string}[]}) {return <ul className="sft-sponsor-grid">{sponsors.map(s=><li key={s.name}>{s.href?<a href={s.href} aria-label={s.name}><img src={s.image} alt={s.name} loading="lazy"/></a>:<img src={s.image} alt={s.name} loading="lazy"/>}</li>)}</ul>;}
export function ContentCard({kind,title,description,image,alt,href,meta}: {kind:'Evento'|'Articolo';title:string;description:string;image:string;alt:string;href:string;meta?:string}) {return <Card className="overflow-hidden p-0"><img src={image} alt={alt} className="aspect-[16/10] w-full object-cover" loading="lazy"/><CardHeader><p className="sft-eyebrow text-primary">{kind}{meta&&` · ${meta}`}</p><CardTitle className="font-display text-2xl"><a className="hover:underline underline-offset-4" href={href}>{title}</a></CardTitle></CardHeader><CardContent className="pb-6 text-sm text-muted-foreground">{description}</CardContent></Card>;}
export function ActivityItem({title,time,description}: {title:string;time:{label:string;iso:string};description?:string}) {return <li className="flex gap-4 border-b py-4"><span className="mt-2 size-2 shrink-0 rounded-full bg-primary" aria-hidden="true"/><div><p className="font-medium">{title}</p>{description&&<p className="mt-1 text-sm text-muted-foreground">{description}</p>}<time dateTime={time.iso} className="mt-2 block text-xs text-muted-foreground">{time.label}</time></div></li>;}
export function SocialTemplate({kind='update',title,description,image,assetBase='./brand',footer='Sapienza Foiling Team',format='post'}:{kind?:'update'|'recruiting'|'technical'|'event'|'sponsor';title:string;description:string;image:string;assetBase?:string;footer?:string;format?:'post'|'story'|'slide'}) {return <article className={cn('sft-template',kind==='technical'&&'technical',format)}><img src={image} alt=""/><BrandLockup inverse assetBase={assetBase}/><div><p className="sft-eyebrow mb-3">{{update:'Dal progetto all’acqua',recruiting:'Dentro il team',technical:'Come funziona',event:'Eventi e regate',sponsor:'Insieme al team'}[kind]}</p><h3>{title}</h3><p>{description}</p></div><footer><span>{footer}</span><span>SFT</span></footer></article>;}
